/*

    UNIVERSIDADE ESTADUAL DA PARA�BA
    CURSO: CI�NCIA DA COMPUTA��O
    COMPONENTE CURRICULAR: LABORAT�RIO DE LINGUAGEM DE PROGRAMA��O 1
    PROFESSOR: DANILO ABREU
    ALUNA: MARIANA FARIAS DINIZ
    PROGRAMA: BIBLIOTECA

*/

#include <stdio.h>
#include <stdlib.h>
#include "menus.h"

int main()
{
    menuPrincipal();
    return 0;
}
