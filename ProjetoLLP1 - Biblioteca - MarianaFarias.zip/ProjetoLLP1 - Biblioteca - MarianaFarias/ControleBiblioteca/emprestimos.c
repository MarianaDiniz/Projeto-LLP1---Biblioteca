#include <stdio.h>
#include <string.h>
#include "emprestimos.h"
#include "livros.h"
#include "alunos.h"

void datadevolucao(Emprestimos e[TAM], int cont) {

    if(e[cont].d.mes==2){
        if(e[cont].d.dia<19){
            e[cont].dv.dia = e[cont].d.dia+10;
            e[cont].dv.mes = e[cont].d.mes;
            e[cont].dv.ano = e[cont].d.ano;
        }
        else{
            e[cont].dv.dia = e[cont].d.dia-18;
            e[cont].dv.mes = e[cont].d.mes+1;
            e[cont].dv.ano = e[cont].d.ano;
        }
    }
    else if(e[cont].d.mes==4 || e[cont].d.mes==6 || e[cont].d.mes==9 || e[cont].d.mes==11){
        if(e[cont].d.dia<21){
            e[cont].dv.dia = e[cont].d.dia+10;
            e[cont].dv.mes = e[cont].d.mes;
            e[cont].dv.ano = e[cont].d.ano;
        }
        else{
            e[cont].dv.dia = e[cont].d.dia-20;
            e[cont].dv.mes = e[cont].d.mes+1;
            e[cont].dv.ano = e[cont].d.ano;
        }
    }
    else if(e[cont].d.mes==12){
        if(e[cont].d.dia<22){
            e[cont].dv.dia = e[cont].d.dia+10;
            e[cont].dv.mes = e[cont].d.mes;
            e[cont].dv.ano = e[cont].d.ano;
        }
        else{
            e[cont].dv.dia = e[cont].d.dia-21;
            e[cont].dv.mes = 1;
            e[cont].dv.ano = e[cont].d.ano+1;
        }
    }
    else{
        if(e[cont].d.dia<22){
            e[cont].dv.dia = e[cont].d.dia+10;
            e[cont].dv.mes = e[cont].d.mes;
            e[cont].dv.ano = e[cont].d.ano;
        }
        else{
            e[cont].dv.dia = e[cont].d.dia-21;
            e[cont].dv.mes = e[cont].d.mes+1;
            e[cont].dv.ano = e[cont].d.ano;
        }
    }
}

int novo_emprestimo(Emprestimos e[TAM], int cont, int contAluno, int contLivro) {

    int i, auxcont=0, auxcont1=0, auxcont2=0;

    printf("\n##################### NOVO EMPRESTIMO #####################\n");
    fflush(stdin);

    printf("\nNome do aluno: ");
    gets(e[cont].dadosAlunos.nome);
    fflush(stdin);

    for(i=0; i<contAluno; i++){
        if(strcmp(e[cont].dadosAlunos.nome, a[i].nome)==0){
            break;
        }
        else{
            printf("\nAluno nao cadastrado!\n");
            printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
            fflush(stdin);
            getchar();
            system("cls");
            return 2;
        }
    }

    printf("\nMatricula: ");
    gets(e[cont].dadosAlunos.matricula);
    fflush(stdin);

    for(i=0; i<contAluno; i++){
        if(strcmp(e[cont].dadosAlunos.matricula, a[i].matricula)==0){
            if(strcmp(e[cont].dadosAlunos.nome, a[i].nome)==0){
                auxcont2++;
            }
        }
    }

    if(auxcont2!=1){
        printf("\nAluno e matricula nao compativeis\n");
        printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
        fflush(stdin);
        getchar();
        system("cls");
        return 8;
    }

    auxcont2=0;

    fflush(stdin);
    printf("\nNome do livro: ");
    gets(e[cont].dadosLivros.nomeLivro);
    fflush(stdin);

    for(i=0; i<contLivro; i++){
        if(strcmp(e[cont].dadosLivros.nomeLivro, l[i].nomeLivro)==0){
            break;
        }
        else{
            printf("\nLivro nao cadastrado\n");
            printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
            fflush(stdin);
            getchar();
            system("cls");
            return 3;
        }
    }

    fflush(stdin);
    printf("\nCodigo do livro: ");
    gets(e[cont].dadosLivros.codigo);
    fflush(stdin);


    for(i=0; i<contLivro; i++){
        if(strcmp(e[cont].dadosLivros.codigo, l[i].codigo)==0){
            if(strcmp(e[cont].dadosLivros.nomeLivro, l[i].nomeLivro)==0){
                auxcont2++;
            }
        }
    }

    if(auxcont2!=1){
        printf("\nLivro e codigo nao compativeis\n");
        printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
        fflush(stdin);
        getchar();
        system("cls");
        return 7;
    }

    for(i=0; i<cont; i++){
        if(strcmp(e[cont].dadosAlunos.nome, e[i].dadosAlunos.nome)==0){
            if(strcmp(e[cont].dadosLivros.nomeLivro, e[i].dadosLivros.nomeLivro)==0){
                auxcont1++;
            }
        }
    }

    if(auxcont1==1){
        printf("\nO aluno ja possui o emprestimo desse titulo.\n");
        printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
        fflush(stdin);
        getchar();
        system("cls");
        return 6;
    }

    for(i=0; i<contLivro; i++){
        if(strcmp(e[cont].dadosLivros.nomeLivro, l[i].nomeLivro)==0){
            if(l[i].qntdExemplares==0){
                printf("\nNao possui exemplares disponiveis com esse titulo.\n");
                printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                fflush(stdin);
                getchar();
                system("cls");
                return 5;
            }
            else
                break;
        }
    }

    for(i=0; i<cont; i++){
        if(strcmp(e[cont].dadosAlunos.matricula, e[i].dadosAlunos.matricula)==0){
            auxcont++;
        }
    }

    if(auxcont==2){
        printf("\nO aluno ja possui a quantidade maxima de emprestimos permitidos.\nNao foi possivel realizar um novo emprestimo!\n");
        printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
        fflush(stdin);
        getchar();
        system("cls");
        return 4;
    }

    for(i=0; i<contLivro; i++){
        if(strcmp(e[cont].dadosLivros.nomeLivro, l[i].nomeLivro)==0){
            l[i].qntdExemplares-=1;
            break;
        }
    }

    printf("\nData do emprestimo \n\n");
    fflush(stdin);
    printf("Dia(dd): ");
    scanf("%d", &e[cont].d.dia);

    while(e[cont].d.dia<1 || e[cont].d.dia>31){
        printf("\nDia nao existente, tente novamente!\nDia(dd): ");
        scanf("%d", &e[cont].d.dia);
    }

    printf("\nMes(mm): ");
    scanf("%d", &e[cont].d.mes);

    while(e[cont].d.mes<1 || e[cont].d.mes>12){
        printf("\nMes nao existente, tente novamente!\nMes(mm): ");
        scanf("%d", &e[cont].d.mes);
    }

    printf("\nAno(aaaa): ");
    scanf("%d", &e[cont].d.ano);

    while(e[cont].d.ano<2019){
        printf("\nTente novamente, esse ano ja passou ou nao existe!\nAno(aaaa): ");
        scanf("%d", &e[cont].d.ano);
    }

    fflush(stdin);

    printf("\n\n##########################################################\n\n");

    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
    fflush(stdin);
    getchar();
    system("cls");
    return -1;
}

int confirmar_devolucao(Emprestimos *e, int cont) {
    int i;
    char matricula[15], codigo[5];

        if(cont!=0){

            printf("\nDigite a matricula do aluno: ");
            scanf("%s", &matricula);
            fflush(stdin);

            printf("\nDigite codigo do livro: ");
            scanf("%s", &codigo);
            fflush(stdin);

        int n = -1, m = -1;

            for(i=0; i<cont; i++){
                if((strcmp(matricula, e[i].dadosAlunos.matricula))==0){
                    n = i;
                    break;
                }
            }

            for(i=0; i<cont; i++){
                if((strcmp(codigo, e[i].dadosLivros.codigo))==0){
                    m = i;
                    break;
                }
            }

            if(n!=-1 && m!=-1){
                for(i=n; i<cont; i++){
                    e[i] = e[i+1];
                }
                l[m].qntdExemplares+=1;
                printf("\nEmprestimo devolvido com sucesso!\n");
                printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                fflush(stdin);
                getchar();
                system("cls");
                return -1;
            }
            else{
                printf("\nEmprestimo nao encontrado!\n");
                printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                fflush(stdin);
                getchar();
                system("cls");
            }
        }
        else{
            printf("Nao possui emprestimo para devolver!\n");
            printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
            fflush(stdin);
            getchar();
            system("cls");
        }
}

int cancelar_emprestimo(Emprestimos *e, int cont) {
    int i;
    char matricula[15], codigo[5];

        if(cont!=0){

            printf("\nDigite a matricula do aluno: ");
            scanf("%s", &matricula);
            fflush(stdin);

            printf("\nDigite codigo do livro: ");
            scanf("%s", &codigo);
            fflush(stdin);

        int n = -1, m = -1;

            for(i=0; i<cont; i++){
                if((strcmp(matricula, e[i].dadosAlunos.matricula))==0){
                    n = i;
                    break;
                }
            }

            for(i=0; i<cont; i++){
                if((strcmp(codigo, e[i].dadosLivros.codigo))==0){
                    m = i;
                    break;
                }
            }

            if(n!=-1 && m!=-1){
                for(i=n; i<cont; i++){
                    e[i] = e[i+1];
                }
                l[m].qntdExemplares+=1;
                printf("\nEmprestimo cancelado com sucesso!\n");
                printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                fflush(stdin);
                getchar();
                system("cls");
                return -1;
            }
            else{
                printf("\nEmprestimo nao encontrado!\n");
                printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                fflush(stdin);
                getchar();
                system("cls");
            }
        }
        else{
            printf("Nao possui emprestimo para remover!\n");
            printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
            fflush(stdin);
            getchar();
            system("cls");
        }
}

void listar_todos(Emprestimos *e, int cont) {
    int i, j, teste;
    Emprestimos aux;

    if(cont!=0){
        for(i=0; i<cont; i++){
            for(j=0; j<cont; j++ ){
                teste = strcmp(e[i].dadosAlunos.nome, e[j].dadosAlunos.nome);
                if(teste<0){
                    strcpy(aux.dadosAlunos.nome, e[i].dadosAlunos.nome);
                    strcpy(aux.dadosAlunos.matricula, e[i].dadosAlunos.matricula);
                    strcpy(aux.dadosLivros.nomeLivro, e[i].dadosLivros.nomeLivro);
                    strcpy(aux.dadosLivros.codigo, e[i].dadosLivros.codigo);
                    aux.d.dia = e[i].d.dia;
                    aux.d.mes = e[i].d.mes;
                    aux.d.ano = e[i].d.ano;
                    strcpy(e[i].dadosAlunos.nome, e[j].dadosAlunos.nome);
                    strcpy(e[i].dadosAlunos.matricula, e[j].dadosAlunos.matricula);
                    strcpy(e[i].dadosLivros.nomeLivro, e[j].dadosLivros.nomeLivro);
                    strcpy(e[i].dadosLivros.codigo, e[j].dadosLivros.codigo);
                    e[i].d.dia = e[j].d.dia;
                    e[i].d.mes = e[j].d.mes;
                    e[i].d.ano = e[j].d.ano;
                    strcpy(e[j].dadosAlunos.nome, aux.dadosAlunos.nome);
                    strcpy(e[j].dadosAlunos.matricula, aux.dadosAlunos.matricula);
                    strcpy(e[j].dadosLivros.nomeLivro, aux.dadosLivros.nomeLivro);
                    strcpy(e[j].dadosLivros.codigo, aux.dadosLivros.codigo);
                    e[j].d.dia = aux.d.dia;
                    e[j].d.mes = aux.d.mes;
                    e[j].d.ano = aux.d.ano;

                }
            }
        }
    }

    printf("######################### EMPRESTIMOS #########################\n");

        if(cont!=0){
            for(i=0; i<cont; i++){
                printf("\nNome: %s\n",e[i].dadosAlunos.nome);
                printf("Matricula: %s\n",e[i].dadosAlunos.matricula);
                printf("Livro: %s\n", e[i].dadosLivros.nomeLivro);
                printf("Codigo do livro: %s\n", e[i].dadosLivros.codigo);

                datadevolucao(e, i);

                if(e[i].d.mes<9){
                    if(e[i].d.dia<10)
                        printf("Data do emprestimo: 0%d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    else
                        printf("Data do emprestimo: %d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    if(e[i].dv.dia<10)
                        printf("Data de devolucao: 0%d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else
                        printf("Data de devolucao: %d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                }
                else if(e[i].d.mes<10){
                    if(e[i].d.dia<10)
                        printf("Data do emprestimo: 0%d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    else
                        printf("Data do emprestimo: %d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    if(e[i].dv.dia<10)
                        printf("Data de devolucao: 0%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else
                        printf("Data de devolucao: %d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                }
                else if(e[i].d.mes==12){
                    if(e[i].d.dia<10)
                        printf("Data do emprestimo: 0%d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    else
                        printf("Data do emprestimo: %d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    if(e[i].dv.dia<10 && e[i].dv.mes==1)
                        printf("Data de devolucao: 0%d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else if(e[i].dv.dia<11 && e[i].dv.mes==1)
                        printf("Data de devolucao: %d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else if(e[i].dv.dia<10)
                        printf("Data de devolucao: 0%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else
                        printf("Data de devolucao: %d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                }
                else{
                    if(e[i].d.dia<10)
                        printf("Data do emprestimo: 0%d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    else
                        printf("Data do emprestimo: %d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    if(e[i].dv.dia<10)
                        printf("Data de devolucao: 0%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else
                        printf("Data de devolucao: %d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                }

                printf("\n\n###############################################################\n");
                puts("");
            }
        }

        printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
        fflush(stdin);
        getchar();
        system("cls");
}

void listar_porLivro(Emprestimos *e, int cont) {
    int i;
    char nome[50];

        fflush(stdin);
        printf("\nDigite o nome do livro: ");
        gets(nome);

    int n = -1;

    printf("\n\n####################### EMPRESTIMOS #######################\n");

        for(i=0; i<cont; i++){
            if((strcmp(nome, e[i].dadosLivros.nomeLivro))==0){
                n = i;
                printf("\nNome: %s\n",e[i].dadosAlunos.nome);
                printf("Matricula: %s\n",e[i].dadosAlunos.matricula);
                printf("Livro: %s\n", e[i].dadosLivros.nomeLivro);
                printf("Codigo do livro: %s\n", e[i].dadosLivros.codigo);

                datadevolucao(e, i);

                if(e[i].d.mes<9){
                    if(e[i].d.dia<10)
                        printf("Data do emprestimo: 0%d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    else
                        printf("Data do emprestimo: %d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    if(e[i].dv.dia<10)
                        printf("Data de devolucao: 0%d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else
                        printf("Data de devolucao: %d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                }
                else if(e[i].d.mes<10){
                    if(e[i].d.dia<10)
                        printf("Data do emprestimo: 0%d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    else
                        printf("Data do emprestimo: %d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    if(e[i].dv.dia<10)
                        printf("Data de devolucao: 0%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else
                        printf("Data de devolucao: %d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                }
                else if(e[i].d.mes==12){
                    if(e[i].d.dia<10)
                        printf("Data do emprestimo: 0%d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    else
                        printf("Data do emprestimo: %d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    if(e[i].dv.dia<10 && e[i].dv.mes==1)
                        printf("Data de devolucao: 0%d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else if(e[i].dv.dia<11 && e[i].dv.mes==1)
                        printf("Data de devolucao: %d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else if(e[i].dv.dia<10)
                        printf("Data de devolucao: 0%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else
                        printf("Data de devolucao: %d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                }
                else{
                    if(e[i].d.dia<10)
                        printf("Data do emprestimo: 0%d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    else
                        printf("Data do emprestimo: %d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    if(e[i].dv.dia<10)
                        printf("Data de devolucao: 0%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else
                        printf("Data de devolucao: %d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                }

                printf("\n\n###########################################################\n");
                puts("");

            }
        }
        if(n == -1){
           printf("\n\nEmprestimo nao encontrado!\n");
           printf("\n###########################################################\n");
           printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
           fflush(stdin);
           getchar();
           system("cls");
        }
        else{
            printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
            fflush(stdin);
            getchar();
            system("cls");
        }
}

void listar_porAluno(Emprestimos *e, int cont) {
    int i;
    char nome[50];

        fflush(stdin);
        printf("\nDigite o nome do aluno: ");
        gets(nome);

    int n = -1;

    printf("\n\n######################### EMPRESTIMOS #########################\n");

        for(i=0; i<cont; i++){
            if((strcmp(nome, e[i].dadosAlunos.nome))==0){
                n = i;
                printf("\nNome: %s\n",e[i].dadosAlunos.nome);
                printf("Matricula: %s\n",e[i].dadosAlunos.matricula);
                printf("Livro: %s\n", e[i].dadosLivros.nomeLivro);
                printf("Codigo do livro: %s\n", e[i].dadosLivros.codigo);

                datadevolucao(e, i);

                if(e[i].d.mes<9){
                    if(e[i].d.dia<10)
                        printf("Data do emprestimo: 0%d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    else
                        printf("Data do emprestimo: %d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    if(e[i].dv.dia<10)
                        printf("Data de devolucao: 0%d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else
                        printf("Data de devolucao: %d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                }
                else if(e[i].d.mes<10){
                    if(e[i].d.dia<10)
                        printf("Data do emprestimo: 0%d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    else
                        printf("Data do emprestimo: %d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    if(e[i].dv.dia<10)
                        printf("Data de devolucao: 0%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else
                        printf("Data de devolucao: %d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                }
                else if(e[i].d.mes==12){
                    if(e[i].d.dia<10)
                        printf("Data do emprestimo: 0%d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    else
                        printf("Data do emprestimo: %d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    if(e[i].dv.dia<10 && e[i].dv.mes==1)
                        printf("Data de devolucao: 0%d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else if(e[i].dv.dia<11 && e[i].dv.mes==1)
                        printf("Data de devolucao: %d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else if(e[i].dv.dia<10)
                        printf("Data de devolucao: 0%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else
                        printf("Data de devolucao: %d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                }
                else{
                    if(e[i].d.dia<10)
                        printf("Data do emprestimo: 0%d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    else
                        printf("Data do emprestimo: %d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
                    if(e[i].dv.dia<10)
                        printf("Data de devolucao: 0%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                    else
                        printf("Data de devolucao: %d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
                }

                printf("\n\n##############################################################\n");
                puts("");

            }
        }
        if(n == -1){
           printf("\n\nEmprestimo nao encontrado!\n");
           printf("\n##############################################################\n");
           printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
           fflush(stdin);
           getchar();
           system("cls");
        }
        else{
            printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
            fflush(stdin);
            getchar();
            system("cls");
        }
}
