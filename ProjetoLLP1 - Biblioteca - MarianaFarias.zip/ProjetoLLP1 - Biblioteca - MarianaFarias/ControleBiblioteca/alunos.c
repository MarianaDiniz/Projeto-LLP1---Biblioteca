#include <stdio.h>
#include <string.h>
#include "alunos.h"

void cadastrar_aluno(Alunos *a, int cont) {
    int i, j;

    printf("\n################### CADASTRO DE ALUNOS ###################\n");

    fflush(stdin);
    printf("\nDIGITE NOME: ");
    gets(a[cont].nome);
    fflush(stdin);

    printf("\nDIGITE MATRICULA: ");
    scanf("%s", &a[cont].matricula);
    fflush(stdin);


    for(i=0; i<cont; i++){
        for(j=cont-1; j>=0; j--){
            if((strcmp(a[cont].matricula, a[j].matricula)==0)){
                do{
                    fflush(stdin);
                    printf("\n Matricula ja existente, tente novamente!\n");
                    printf("\nDIGITE MATRICULA: ");
                    gets(a[cont].matricula);
                    fflush(stdin);
                }while((strcmp(a[cont].matricula, a[i].matricula)==0)||(strcmp(a[cont].matricula, a[j].matricula)==0));
            }
        }
    }

    printf("\nDIGITE CPF: ");
    scanf("%s", &a[cont].cpf);
    fflush(stdin);

    printf("\n##########################################################\n");
    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
    fflush(stdin);
    getchar();
    system("cls");
}

void editar_aluno(Alunos *a, int cont) {

    int i, j;
    char matricula[15];

    if(cont!=0){
            printf("\nDigite a matricula: ");
            scanf("%s", &matricula);

        int n = -1;
            for(i=0; i<cont; i++){
                if((strcmp(matricula, a[i].matricula))==0){
                    n = i;
                    break;
                }
            }

        if(n != -1){

            fflush(stdin);
            printf("\nDIGITE NOME: ");
            gets(a[n].nome);
            fflush(stdin);

            printf("DIGITE MATRICULA: ");
            gets(a[n].matricula);
            fflush(stdin);

            for(i=0; i<cont; i++){
                for(j=cont-1; j>=0; j--){
                    if(((strcmp(a[i].matricula, a[n].matricula)==0)||(strcmp(a[j].matricula, a[n].matricula)==0)) && (n!=i && n!=j)){
                            fflush(stdin);
                            printf("\n Matricula ja existente, tente novamente!\n");
                            printf("\nDIGITE MATRICULA: ");
                            gets(a[n].matricula);
                            fflush(stdin);
                    }
                }
            }

            printf("DIGITE CPF: ");
            scanf("%s", &a[n].cpf);
            fflush(stdin);

        }
        else
            printf("\nAluno nao encontrado!\n");
    }
    else
            printf("Nao possui alunos para editar!\n");

    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
    fflush(stdin);
    getchar();
    system("cls");
}

int remover_aluno(Alunos *a, int cont) {
    int i;
    char matricula[15];

        if(cont!=0){

            printf("\nDigite a matricula do aluno: ");
            scanf("%s", &matricula);

        int n = -1;

            for(i=0; i<cont; i++){
                if((strcmp(matricula, a[i].matricula))==0){
                    n = i;
                    printf("\nNome: %s\n",a[i].nome);
                    printf("Matricula: %s\n",a[i].matricula);
                    printf("CPF: %s\n", a[i].cpf);
                    break;
                }
            }

            if(n!=-1){
                printf("\nDeseja realmente excluir esse aluno?\n1. SIM\n2. NAO\n\nDigite opcao: ");
                scanf("%d", &i);

                if(i==1){
                    for(i=n; i<cont; i++){
                        a[i] = a[i+1];
                    }
                    printf("\nAluno removido com sucesso!\n");
                    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                    fflush(stdin);
                    getchar();
                    system("cls");
                    return -1;
                }
                else if(i==2){
                    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                    fflush(stdin);
                    getchar();
                    system("cls");
                    return 0;
                }
                else
                    printf("\n\nNAO POSSUI ESSA OPCAO!\n");
                    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                    fflush(stdin);
                    getchar();
                    system("cls");
                    return 0;
            }
            else
                printf("\nAluno nao encontrado!\n");
        }
        else
            printf("Nao possui alunos para remover!\n");
            printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
            fflush(stdin);
            getchar();
            system("cls");
}

void listar_alunos(Alunos *a, int cont) {
    int i, j, teste;
    Alunos aux;

    if(cont!=0){
        for(i=0; i<cont; i++){
            for(j=0; j<cont; j++ ){
                teste = strcmp(a[i].nome, a[j].nome);
                if(teste<0){
                    strcpy(aux.nome, a[i].nome);
                    strcpy(aux.matricula, a[i].matricula);
                    strcpy(aux.cpf, a[i].cpf);
                    strcpy(a[i].nome, a[j].nome);
                    strcpy(a[i].matricula, a[j].matricula);
                    strcpy(a[i].cpf, a[j].cpf);
                    strcpy(a[j].nome, aux.nome);
                    strcpy(a[j].matricula, aux.matricula);
                    strcpy(a[j].cpf, aux.cpf);
                }
            }
        }
    }

    printf("######################### ALUNOS #########################\n");

        if(cont!=0){
            for(i=0; i<cont; i++){
                printf("\nNome: %s\n",a[i].nome);
                printf("Matricula: %s\n",a[i].matricula);
                printf("CPF: %s\n", a[i].cpf);
                printf("\n##########################################################\n");
                puts("");
            }
        }

        printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
        fflush(stdin);
        getchar();
        system("cls");
}
