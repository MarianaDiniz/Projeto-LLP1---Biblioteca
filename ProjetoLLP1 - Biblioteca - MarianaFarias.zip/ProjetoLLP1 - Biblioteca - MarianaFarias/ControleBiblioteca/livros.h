#ifndef LIVROS_H
#define LIVROS_H

#define TAM 1000

typedef struct {
    int  qntdExemplares;
    char codigo[5], nomeLivro[50], nomeAutor[50], areaConhecimento[30];

}Livros;

Livros l[TAM];


void cadastrar_livro(Livros l[TAM], int cont);
void editar_livro(Livros *l, int cont);
int remover_livro(Livros *l, int cont);
void listar_livros(Livros *l, int cont);

#endif