#ifndef ALUNOS_H
#define ALUNOS_H

#define TAM 1000

typedef struct {

    char nome[50], matricula[15], cpf[15];

}Alunos;

Alunos a[TAM];


void cadastrar_aluno(Alunos *a, int cont);
void editar_aluno(Alunos *a, int cont);
int remover_aluno(Alunos *a, int cont);
void listar_alunos(Alunos *a, int cont);


#endif