#ifndef EMPRESTIMOS_H
#define EMPRESTIMOS_H

#define TAM 1000

#include "livros.h"
#include "alunos.h"

typedef struct{

    int dia, mes, ano;

}data;

typedef struct {

    Livros dadosLivros;
    Alunos dadosAlunos;
    data d, dv;

}Emprestimos;

Emprestimos e[TAM];

void datadevolucao(Emprestimos e[TAM], int cont);
int novo_emprestimo(Emprestimos e[TAM], int cont, int contAluno, int contLivro);
int confirmar_devolucao(Emprestimos *e, int cont);
int cancelar_emprestimo(Emprestimos *e, int cont);
void listar_todos(Emprestimos *e, int cont);
void listar_porLivro(Emprestimos *e, int cont);
void listar_porAluno(Emprestimos *e, int cont);

#endif
