#include <stdio.h>
#include <string.h>
#include "menus.h"
#include "armazena_dados.h"


void salvar_informacoes(int contAluno, Alunos a[TAM], int contLivro, Livros l[TAM], int contEmprestimo, Emprestimos e[TAM]) {

    int i;
    FILE *arq_alunos, *arq_livros, *arq_emprestimos;

    //************************ INFORMA��ES DOS ALUNOS *****************************

    arq_alunos = fopen("alunos.txt", "w+r");

    for(i=0; i<contAluno; i++){
        fprintf(arq_alunos, "%s\n", a[i].nome);
        fprintf(arq_alunos, "%s\n", a[i].matricula);
        fprintf(arq_alunos, "%s\n\n", a[i].cpf);
    }

    fclose(arq_alunos);

    //************************ INFORMA��ES DOS LIVROS ******************************

    arq_livros = fopen("livros.txt", "w+r");

    for(i=0; i<contLivro; i++){
        fprintf(arq_livros, "%s\n", l[i].codigo);
        fprintf(arq_livros, "%s\n",l[i].nomeLivro);
        fprintf(arq_livros, "%s\n",l[i].nomeAutor);
        fprintf(arq_livros, "%d\n", l[i].qntdExemplares);
        fprintf(arq_livros, "%s\n\n", l[i].areaConhecimento);
    }

    fclose(arq_livros);

    //************************ INFORMA��ES DOS EMPR�STIMOS *************************

    arq_emprestimos = fopen("emprestimos.txt", "w+r");

    for(i=0; i<contEmprestimo; i++){
        fprintf(arq_emprestimos, "%s\n",e[i].dadosAlunos.nome);
        fprintf(arq_emprestimos, "%s\n",e[i].dadosAlunos.matricula);
        fprintf(arq_emprestimos, "%s\n", e[i].dadosLivros.nomeLivro);
        fprintf(arq_emprestimos, "%s\n", e[i].dadosLivros.codigo);

        if(e[i].d.mes<9){
            if(e[i].d.dia<10)
                fprintf(arq_emprestimos, "0%d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
            else
                fprintf(arq_emprestimos, "%d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
            if(e[i].dv.dia<10)
                fprintf(arq_emprestimos, "0%d/0%d/%d\n\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
            else
                fprintf(arq_emprestimos, "%d/0%d/%d\n\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
        }
        else if(e[i].d.mes<10){
            if(e[i].d.dia<10)
                fprintf(arq_emprestimos, "0%d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
            else
                fprintf(arq_emprestimos, "%d/0%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
            if(e[i].dv.dia<10)
                fprintf(arq_emprestimos, "0%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
            else
                fprintf(arq_emprestimos, "%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
        }
        else if(e[i].d.mes==12){
            if(e[i].d.dia<10)
                fprintf(arq_emprestimos, "0%d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
            else
                fprintf(arq_emprestimos, "%d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
            if(e[i].dv.dia<10 && e[i].dv.mes==1)
                fprintf(arq_emprestimos, "0%d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
            else if(e[i].dv.dia<11 && e[i].dv.mes==1)
                fprintf(arq_emprestimos, "%d/0%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
            else if(e[i].dv.dia<10)
                fprintf(arq_emprestimos, "0%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
            else
                fprintf(arq_emprestimos, "%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
        }
        else{
            if(e[i].d.dia<10)
                fprintf(arq_emprestimos, "0%d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
            else
                fprintf(arq_emprestimos, "%d/%d/%d\n", e[i].d.dia, e[i].d.mes, e[i].d.ano);
            if(e[i].dv.dia<10)
                fprintf(arq_emprestimos, "0%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
            else
                fprintf(arq_emprestimos, "%d/%d/%d\n", e[i].dv.dia, e[i].dv.mes, e[i].dv.ano);
        }

    fclose(arq_emprestimos);
    }
}

