#include <stdio.h>
#include <string.h>
#include "menus.h"
#include "livros.h"
#include "alunos.h"
#include "emprestimos.h"

int menuAcervo(int cont) {

    char opcao;

    do{
        system("color e0");

        printf("\n************************ ACERVO ***************************\n\n");
        printf("    (1) Cadastrar livro                                \n");
        printf("    (2) Editar livro                                   \n");
        printf("    (3) Remover livro                                  \n");
        printf("    (4) Listar livros cadastrados                      \n");
        printf("    (5) Voltar para menu principal                     \n");

        fflush(stdin);
        printf("\n  Digite sua opcao: ");
        scanf("%c", &opcao);

        printf("\n\n***********************************************************\n");

        system("cls");

        switch(opcao) {

            case '1':
                cadastrar_livro(l, cont);
                cont++;
                break;
            case '2':
                editar_livro(l, cont);
                break;
           case '3':
                if((remover_livro(l, cont))== -1)
                    cont--;
                break;
            case '4':
                if(cont!=0)
                    listar_livros(l, cont);
                 else{
                    printf("Lista Vazia!\n");
                    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                    fflush(stdin);
                    getchar();
                    system("cls");}
                break;
            case '5':
                break;
            default:
                printf("Nao possui essa opcao, tente novamente!\n");
                printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                fflush(stdin);
                getchar();
                system("cls");
                break;
        }
    }while(opcao!='5');

    return cont;
}

int menuAluno(int cont) {

    char opcao;

    do {
        system("color e0");

        printf("\n************************** ALUNO **************************\n\n");
        printf("    (1) Cadastrar aluno\n");
        printf("    (2) Editar aluno\n");
        printf("    (3) Remover aluno\n");
        printf("    (4) Listar alunos cadastrados\n");
        printf("    (5) Sair do menu Aluno\n\n");

        fflush(stdin);
        printf("  Digite sua opcao: ");
        scanf("%c", &opcao);

        printf("\n***********************************************************\n\n");

        system("cls");

        switch(opcao) {

            case '1':
                cadastrar_aluno(a, cont);
                cont++;
                break;
            case '2':
                editar_aluno(a, cont);
                break;
            case '3':
                if((remover_aluno(a, cont))== -1)
                    cont--;
                break;
            case '4':
                if(cont!=0)
                    listar_alunos(a, cont);
                 else{
                    printf("Lista Vazia!\n");
                    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                    fflush(stdin);
                    getchar();
                    system("cls");}
                break;
            case '5':
                break;
            default:
                printf("Nao possui essa opcao, tente novamente!\n");
                printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                fflush(stdin);
                getchar();
                system("cls");
                break;
        }
    }while(opcao!='5');

    return cont;
}

void menuListarEmprestimo(Emprestimos *e, int cont) {
    int opcao;

    do {
        system("color 50");

        printf("***************** OPCOES LISTAR EMPRESTIMOS *******************\n\n");
        printf("    (1) Listar todos os emprestimos\n");
        printf("    (2) Listar por livro especifico\n");
        printf("    (3) Listar por aluno especifico\n");
        printf("    (4) Voltar ao menu Emprestimo\n\n");

        printf("  Digite sua opcao: ");
        scanf("%d", &opcao);

        printf("\n***************************************************************\n\n");
        system("cls");

        switch(opcao) {

            case 1:
                listar_todos(e, cont);
                break;
            case 2:
                listar_porLivro(e, cont);
                break;
            case 3:
                listar_porAluno(e, cont);
                break;
            case 4:
                break;
            default:
                printf("Nao possui essa opcao, tente novamente!\n");
                printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                fflush(stdin);
                getchar();
                system("cls");
                break;
        }
    }while(opcao!=4);

}

int menuEmprestimo(int contAluno, int contLivro, int cont) {

    int opcao;

    do {
        system("color e0");

        printf("\n************************* Emprestimo ***************************\n\n");
        printf("    (1) Novo emprestimo\n");
        printf("    (2) Confirmar devolucao\n");
        printf("    (3) Cancelar emprestimo\n");
        printf("    (4) Listar emprestimos\n");
        printf("    (5) Sair do menu Emprestimo\n");

        printf("\n  Digite sua opcao: ");
        scanf("%d", &opcao);

        printf("\n****************************************************************\n\n");

        system("cls");

        switch(opcao) {

            case 1:
                if(contAluno!=0 && contLivro!=0){
                    if((novo_emprestimo(e, cont, contAluno, contLivro))== -1)
                        cont++;
                }
                else{
                    printf("Nao possui alunos ou livros cadastrados para realizar essa opcao!\n");
                    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                    fflush(stdin);
                    getchar();
                    system("cls");}
                break;
            case 2:
                if((confirmar_devolucao(e, cont))== -1)
                    cont--;
                break;
            case 3:
                if((cancelar_emprestimo(e, cont))== -1)
                    cont--;
                break;
            case 4:
                if(cont!=0)
                    menuListarEmprestimo(e, cont);
                 else{
                    printf("Lista Vazia!\n");
                    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                    fflush(stdin);
                    getchar();
                    system("cls");}
                break;
            case 5:
                break;
            default:
                printf("Nao possui essa opcao, tente novamente!\n");
                printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                fflush(stdin);
                getchar();
                system("cls");
                break;
        }
    }while(opcao!=5);

    return cont;
}

void menuPrincipal() {

    int contAluno = 0;
    int contLivro = 0;
    int contEmprestimo = 0;

    char opcao;

    do {
        system("color 60");

        printf("\n-----------------------------------BIBLIOTECA-----------------------------------------\n\n\n");

        printf("    (1) Acervo\n");
        printf("    (2) Aluno\n");
        printf("    (3) Emprestimo\n");
        printf("    (4) Sair\n");
        printf("\n                                                                     Data: %s   ", __DATE__);

        fflush(stdin);
        printf("\n\n\n  Digite sua opcao: ");
        scanf("%c", &opcao);
        printf("\n");

        system("cls");

        switch(opcao){

        case '1':
            contLivro = menuAcervo(contLivro);
            break;
        case '2':
            contAluno = menuAluno(contAluno);
            break;
        case '3':
            contEmprestimo = menuEmprestimo(contAluno, contLivro, contEmprestimo);
            break;
        case '4':
            printf("\nSaindo...\n\n");
            break;
        default:
            printf("Nao possui essa opcao, tente novamente!\n");
            printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
            fflush(stdin);
            getchar();
            system("cls");
            break;
        }

    }while(opcao!='4');

    salvar_informacoes(contAluno, a, contLivro, l, contEmprestimo, e);
}
