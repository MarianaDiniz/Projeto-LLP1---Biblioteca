#ifndef ARMAZENA_DADOS_H
#define ARMAZENA_DADOS_H

void salvar_informacoes(int contAluno, Alunos a[TAM], int contLivro, Livros l[TAM], int contEmprestimo, Emprestimos e[TAM]);

#endif