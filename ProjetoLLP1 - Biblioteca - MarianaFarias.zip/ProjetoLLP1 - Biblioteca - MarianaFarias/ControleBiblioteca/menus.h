#ifndef MENUS_H
#define MENUS_H

#include "emprestimos.h"

int menuAcervo(int cont);
int menuAluno(int cont);
void menuListarEmprestimo(Emprestimos *e, int cont);
int menuEmprestimo(int contAluno, int contLivro, int cont);
void menuPrincipal();

#endif
