#include <stdio.h>
#include <string.h>
#include "livros.h"

void cadastrar_livro(Livros l[TAM], int cont) {

    int i, j;

    printf("\n################### CADASTRO DE LIVROS ###################\n");
    fflush(stdin);

    printf("\nCodigo: ");
    scanf("%s", &l[cont].codigo);
    fflush(stdin);

    for(i=0; i<cont; i++){
        for(j=cont-1; j>=0; j--){
            if((strcmp(l[cont].codigo, l[j].codigo)==0)){
                do{
                    fflush(stdin);
                    printf("\n Codigo ja existente, tente novamente!\n");
                    printf("\nDigite codigo: ");
                    gets(l[cont].codigo);
                    fflush(stdin);
                }while((strcmp(l[cont].codigo, l[i].codigo)==0)||(strcmp(l[cont].codigo, l[j].codigo)==0));
            }
        }
    }

    printf("\nNome do livro: ");
    gets(l[cont].nomeLivro);
    fflush(stdin);

    printf("\nNome do autor: ");
    gets(l[cont].nomeAutor);
    fflush(stdin);

    printf("\nQuantidade de exemplares: ");
    scanf("%d", &l[cont].qntdExemplares);
    fflush(stdin);

    printf("\nArea de conhecimento: ");
    gets(l[cont].areaConhecimento);
    fflush(stdin);

    printf("\n##########################################################\n\n");

    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
    fflush(stdin);
    getchar();
    system("cls");
}

void editar_livro(Livros *l, int cont) {

    int i, j;
    char codaux[5];


    if(cont!=0){

        printf("\nDigite codigo do livro: ");
        scanf("%s", &codaux);

        int n = -1;
            for(i=0; i<cont; i++){
                if((strcmp(codaux, l[i].codigo))==0){
                    n = i;
                    break;
                }
            }

        if(n != -1){

            printf("\nCodigo: ");
            scanf("%s", &l[n].codigo);
            fflush(stdin);

            for(i=0; i<cont; i++){
                for(j=cont-1; j>=0; j--){
                    if(((strcmp(l[i].codigo, l[n].codigo)==0)||(strcmp(l[j].codigo, l[n].codigo)==0)) && (n!=i && n!=j)){
                            fflush(stdin);
                            printf("\n Codigo ja existente, tente novamente!\n");
                            printf("\nDigite codigo: ");
                            gets(l[n].codigo);
                            fflush(stdin);
                    }
                }
            }

            printf("\nNome do livro: ");
            gets(l[n].nomeLivro);
            fflush(stdin);

            printf("\nNome do autor: ");
            gets(l[n].nomeAutor);
            fflush(stdin);

            printf("\nQuantidade de exemplares: ");
            scanf("%d", &l[n].qntdExemplares);
            fflush(stdin);

            printf("\nArea de conhecimento: ");
            gets(l[n].areaConhecimento);
            fflush(stdin);


        }
        else
            printf("\nLivro nao encontrado!\n");
    }
    else
        printf("Nao possui Livros para editar!\n");

    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
    fflush(stdin);
    getchar();
    system("cls");

}

int remover_livro(Livros *l, int cont) {

    int i;
    char codaux[5];

        if(cont!=0){

            printf("\nDigite o codigo do livro: ");
            scanf("%s", &codaux);

        int n = -1;

            for(i=0; i<cont; i++){
                if((strcmp(codaux, l[i].codigo))==0){
                    n = i;
                    printf("\nCodigo: %s\n",l[i].codigo);
                    printf("Livro: %s\n",l[i].nomeLivro);
                    printf("Autor: %s\n",l[i].nomeAutor);
                    printf("Exemplares: %d\n", l[i].qntdExemplares);
                    printf("Area de conhecimento: %s\n\n", l[i].areaConhecimento);
                    break;
                }
            }

            if(n!=-1){
                printf("Deseja realmente excluir esse livro?\n1. SIM\n2. NAO\n\nDigite opcao: ");
                scanf("%d", &i);

                if(i==1){

                    for(i=n; i<cont; i++){
                        l[i] = l[i+1];
                    }
                    printf("\nLivro removido com sucesso!\n");
                    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                    fflush(stdin);
                    getchar();
                    system("cls");
                    return -1;
                }
                else if(i==2){
                    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                    fflush(stdin);
                    getchar();
                    system("cls");
                    return 0;
                }
                else
                    printf("\n\nNAO POSSUI ESSA OPCAO!\n");
                    printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
                    fflush(stdin);
                    getchar();
                    system("cls");
                    return 0;
            }
            else
                printf("\nLivro nao encontrado!\n");
        }
        else
            printf("Nao possui livros para remover!\n");

        printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
        fflush(stdin);
        getchar();
        system("cls");
}


void listar_livros(Livros *l, int cont){

    int i, j, teste, aux;
    Livros auxl;

    if(cont!=0){
        for(i=0; i<cont; i++){
            for(j=0; j<cont; j++ ){
                teste = strcmp(l[i].nomeLivro, l[j].nomeLivro);
                if(teste<0){
                    strcpy(auxl.codigo, l[i].codigo);
                    strcpy(auxl.nomeLivro, l[i].nomeLivro);
                    strcpy(auxl.nomeAutor, l[i].nomeAutor);
                    strcpy(auxl.areaConhecimento, l[i].areaConhecimento);
                    aux = l[i].qntdExemplares;
                    strcpy(l[i].codigo, l[j].codigo);
                    strcpy(l[i].nomeLivro, l[j].nomeLivro);
                    strcpy(l[i].nomeAutor, l[j].nomeAutor);
                    strcpy(l[i].areaConhecimento, l[j].areaConhecimento);
                    l[i].qntdExemplares = l[j].qntdExemplares;
                    strcpy(l[j].codigo, auxl.codigo);
                    strcpy(l[j].nomeLivro, auxl.nomeLivro);
                    strcpy(l[j].nomeAutor, auxl.nomeAutor);
                    strcpy(l[j].areaConhecimento, auxl.areaConhecimento);
                    l[j].qntdExemplares = aux;
                }
            }
        }
    }

    printf("\n######################### LIVROS #########################\n");

        if(cont!=0){
            for(i=0; i<cont; i++){
                printf("\nCodigo: %s\n",l[i].codigo);
                printf("Livro: %s\n",l[i].nomeLivro);
                printf("Autor: %s\n",l[i].nomeAutor);
                printf("Exemplares: %d\n", l[i].qntdExemplares);
                printf("Area de conhecimento: %s\n\n", l[i].areaConhecimento);
                printf("\n##########################################################\n");
                puts("");
            }
        }

        printf("\n\nPRESSIONE ENTER PARA VOLTAR AO MENU...\n\n");
        fflush(stdin);
        getchar();
        system("cls");
}

